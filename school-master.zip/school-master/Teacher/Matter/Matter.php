<?php

namespace Teacher\Matter;

class Matter extends \Domain\Matter\Matter
{
    protected $visible = ['name', 'workload'];
}
