<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>School</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/dist.css">
  </head>
  <body>
    <app></app>
    <script src="js/dist.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
