
export const URI = "/api/v1";
