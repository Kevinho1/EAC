export function message(text){
    Materialize.toast(text, 2000);
}