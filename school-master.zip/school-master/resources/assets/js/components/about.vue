<template>

      <div class="card blue-grey darken-1">
        <div class="card-content white-text">
          <span class="card-title">Sistema para gerenciamento de escola</span>
          <p>
            <ul class="collection ">
              <li class="collection-item blue-grey darken-2">Todo desenvolvido com TDD</li>
              <li  class="collection-item blue-grey darken-2">Cadastro de alunos</li>
              <li  class="collection-item blue-grey darken-2">Cadastro de cedente (Emitente da cobrança)</li>
              <li  class="collection-item blue-grey darken-2">Cadastro de funcionários</li>
              <li class="collection-item blue-grey darken-2">Cadastro de horários</li>
              <li  class="collection-item blue-grey darken-2">Cadastro de matérias</li>
              <li class="collection-item blue-grey darken-2">Cadastro de lições</li>
              <li class="collection-item blue-grey darken-2">Cadastro de professores</li>
              <li class="collection-item blue-grey darken-2">Cadastro de turmas</li>
              <li class="collection-item blue-grey darken-2">Cadastro de usuários (Aluno, Funcionário e Professor)</li>
              <li class="collection-item blue-grey darken-2">Geração de boleto automático (caixa e. federal, banco do brasil, banco itau, hsbc, santander)</li>
            </ul>
          </p>
        </div>
      </div>


      <div class="card blue-grey darken-1">
        <div class="card-content white-text">
          <span class="card-title">Vídeos</span>
          <p>
          <iframe  width="640" height="360" src="https://www.youtube.com/embed/kd0y0e_2dR4" frameborder="0" allowfullscreen></iframe>
          </p>
        </div>
      </div>



</template>
<script>
  export default{

  }
</script>
